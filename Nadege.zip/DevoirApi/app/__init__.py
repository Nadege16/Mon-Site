from flask import Flask, render_template
from flask_restful import Api
from flasgger import Swagger
from app.routes import UserListResource, UserResource

def create_app():
    app = Flask(__name__)  # Crée l'application Flask
    api = Api(app)  # Crée l'API Flask-RESTful
    swagger = Swagger(app)  # Active Swagger pour l'application

    # Routes de l'API
    api.add_resource(UserListResource, '/users')
    api.add_resource(UserResource, '/users/<int:id>')

    # Route pour la page d'accueil
    @app.route('/')
    def index():
        users = [
            {'name': 'Alice', 'bio': 'Développeuse', 'photo': 'alice.jpg', 'cv': 'alice_cv.pdf'},
            {'name': 'Bob', 'bio': 'Designer', 'photo': 'bob.jpg', 'cv': 'bob_cv.pdf'}
        ]
        return render_template('index.html', users=users)  # Rend la page HTML avec la liste des utilisateurs

    return app
