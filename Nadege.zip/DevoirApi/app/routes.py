from flask_restful import Resource
from flask import request
from flasgger import swag_from  # Importer le décorateur swag_from
from app.models import users  # Assurez-vous que 'users' est défini dans app/models.py

class UserListResource(Resource):
    @swag_from({
        'tags': ['User'],  # Catégorie de l'API, ici "User"
        'description': 'Récupérer tous les utilisateurs',  # Description de ce que fait cette route
        'responses': {
            '200': {  # Code de réponse 200 signifie succès
                'description': 'Liste des utilisateurs',  # Ce que l'on retourne en cas de succès
                'schema': {
                    'type': 'array',  # Type de la réponse est un tableau
                    'items': {
                        'type': 'object',  # Chaque utilisateur est un objet
                        'properties': {  # Définir les propriétés d'un utilisateur
                            'id': {'type': 'integer'},  # ID de l'utilisateur (entier)
                            'name': {'type': 'string'},  # Nom de l'utilisateur
                            'photo': {'type': 'string'},  # Photo de l'utilisateur
                            'bio': {'type': 'string'},  # Bio de l'utilisateur
                            'cv': {'type': 'string'}  # CV de l'utilisateur
                        }
                    }
                }
            }
        }
    })
    def get(self):
        """ Récupérer la liste de tous les utilisateurs """
        return users, 200  # Retourne la liste des utilisateurs avec un code 200

    def post(self):
        """ Ajouter un nouvel utilisateur """
        data = request.get_json()  # Récupère les données envoyées dans le body de la requête
        user = {
            'id': len(users) + 1,  # L'ID est automatiquement attribué comme l'index suivant
            'name': data['name'],
            'photo': data['photo'],
            'bio': data['bio'],
            'cv': data['cv']
        }
        users.append(user)  # Ajoute l'utilisateur à la liste
        return user, 201  # Retourne l'utilisateur ajouté avec un code 201


class UserResource(Resource):
    def get(self, id):
        """ Récupérer les détails d'un utilisateur spécifique """
        user = next((u for u in users if u['id'] == id), None)  # Cherche l'utilisateur par ID
        if user:
            return user, 200  # Si trouvé, retourne l'utilisateur avec un code 200
        return {'message': 'Utilisateur non trouvé'}, 404  # Si non trouvé, retourne une erreur 404

    def put(self, id):
        """ Mettre à jour un utilisateur spécifique """
        data = request.get_json()  # Récupère les données envoyées dans le body de la requête
        user = next((u for u in users if u['id'] == id), None)  # Cherche l'utilisateur par ID
        if user:
            user.update(data)  # Met à jour les informations de l'utilisateur
            return user, 200  # Retourne l'utilisateur mis à jour
        return {'message': 'Utilisateur non trouvé'}, 404  # Si l'utilisateur n'existe pas, retourne une erreur 404

    def delete(self, id):
        """ Supprimer un utilisateur spécifique """
        global users  # Utilisation de la variable globale pour la modification de la liste
        users = [u for u in users if u['id'] != id]  # Filtre les utilisateurs pour supprimer celui dont l'ID correspond
        return {'message': 'Utilisateur supprimé'}, 200  # Retourne un message de succès
