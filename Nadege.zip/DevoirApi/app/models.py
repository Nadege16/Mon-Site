# app/models.py

# Liste simulée d'utilisateurs avec les informations comme dans votre exemple
users = [
    {
        'id': 1,
        'name': "Alice",
        'photo': "alice.jpg",
        'bio': "Développeuse",
        'cv': "alice_cv.pdf"
    },
    {
        'id': 2,
        'name': "Bob",
        'photo': "bob.jpg",
        'bio': "Designer",
        'cv': "bob_cv.pdf"
    }
]
